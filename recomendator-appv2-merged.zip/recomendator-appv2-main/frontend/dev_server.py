"""Local dev server for the frontend, run as its own process.

app.js calls a relative path, ``/api/...`` (see the ``const API = "/api"``
line near the top of app.js). That works unmodified in two places: Cloud
Run, where nginx's default.conf.template proxies ``/api/`` to BACKEND_URL,
and the backend's own SERVE_FRONTEND=1 mode, where one process serves both
so there is no cross-origin request to make.

Running the frontend as a second local process needs the same proxy nginx
does in production, or every fetch("/api/...") resolves against *this*
server's own origin and 404s. This script is that proxy, in the standard
library only - no nginx, no Docker, nothing to install. It is dev tooling,
not a deployment artifact; it is never what Cloud Run runs.

Usage:
    BACKEND_URL=http://localhost:8080 python3 dev_server.py [port]

Defaults to port 8081 and BACKEND_URL=http://localhost:8080.
"""
from __future__ import annotations

import os
import sys
import urllib.error
import urllib.request
from http.server import HTTPServer, SimpleHTTPRequestHandler

BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:8080").rstrip("/")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8081
DIRECTORY = os.path.dirname(os.path.abspath(__file__))


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def do_GET(self):
        if self.path.startswith("/api/"):
            self._proxy("GET")
        else:
            super().do_GET()

    def do_POST(self):
        self._proxy("POST")

    def do_PUT(self):
        self._proxy("PUT")

    def do_DELETE(self):
        self._proxy("DELETE")

    def _proxy(self, method: str) -> None:
        """Forward one request to the backend and relay its response verbatim.

        Streams the body through unparsed - JSON, multipart file uploads (the
        quote-upload flow), everything - so this does not need to understand
        the shape of any endpoint, only forward bytes.
        """
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length else None
        target = BACKEND_URL + self.path

        headers = {
            k: v for k, v in self.headers.items()
            if k.lower() not in ("host", "content-length")
        }
        request = urllib.request.Request(
            target, data=body, headers=headers, method=method)

        try:
            with urllib.request.urlopen(request, timeout=300) as response:
                self._relay(response.status, response.headers, response.read())
        except urllib.error.HTTPError as exc:
            # A 4xx/5xx from the backend - e.g. your PolicyEditError 400 - is
            # not a proxy failure. Relay it exactly so curl and the browser
            # see the real status and body, not a generic 500 from here.
            self._relay(exc.code, exc.headers, exc.read())
        except urllib.error.URLError as exc:
            self.send_response(502)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(
                f"Cannot reach backend at {target}\n{exc.reason}\n"
                f"Is uvicorn running? Is BACKEND_URL correct?".encode())

    def _relay(self, status: int, headers, body: bytes) -> None:
        self.send_response(status)
        for key, value in headers.items():
            if key.lower() not in ("transfer-encoding", "connection"):
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # Quieter than the default, and marks proxied calls so a glance at
        # the terminal shows whether a request ever reached the backend.
        tag = "proxy->backend" if self.path.startswith("/api/") else "static"
        sys.stderr.write(f"[{tag}] {fmt % args}\n")


if __name__ == "__main__":
    print(f"Serving {DIRECTORY} on http://localhost:{PORT}")
    print(f"Proxying /api/* to {BACKEND_URL}")
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
