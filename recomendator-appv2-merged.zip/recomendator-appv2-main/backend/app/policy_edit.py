"""Editing a policy threshold, in one place.

Two callers now change `policy_config`: the Policy in force screen through
`PUT /api/reference/policy`, and the agent through its `set_policy_value`
tool. They must agree on what is a legal value, or a threshold the UI refuses
becomes one the agent can set by asking politely. So the bounds and the write
live here and both callers go through them.

Every write is recorded in `policy_change`. That was a documented gap while a
human editing a form was the only way a threshold moved; it stops being
tolerable once an agent can move one mid-conversation, because "the ceiling is
4% now" needs an answer to "who set it to 4%, and what was it before".
"""
from __future__ import annotations

import logging
from decimal import Decimal, InvalidOperation

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import PolicyChange, PolicyConfig

log = logging.getLogger(__name__)

# Sanity bounds per key, so a typo (a negative percentage, a fractional
# integer count) is caught here rather than surfacing three requests later as
# a confusing engine error. Not a business rule - a guardrail on the input.
# (min, max, integer_only)
POLICY_LIMITS: dict[str, tuple[Decimal, Decimal, bool]] = {
    "fx_usd_eur": (Decimal("0.01"), Decimal("100"), False),
    "gallon_to_litre": (Decimal("1"), Decimal("10"), False),
    "price_rounding_dp": (Decimal("0"), Decimal("6"), True),
    "line_total_tolerance_pct": (Decimal("0"), Decimal("100"), False),
    "moq_overbuy_threshold_pct": (Decimal("0"), Decimal("1000"), False),
    "ceiling_materiality_pct": (Decimal("0"), Decimal("100"), False),
    "promotion_band_pct": (Decimal("0"), Decimal("100"), False),
    "primary_allocation_pct": (Decimal("0"), Decimal("100"), False),
    "max_vendor_share_pct": (Decimal("0"), Decimal("100"), False),
    "min_supplier_count": (Decimal("1"), Decimal("20"), True),
    "extraction_confidence_threshold": (Decimal("0"), Decimal("1"), False),
}


class PolicyEditError(ValueError):
    """A rejected edit, with a message meant to be shown to whoever asked."""


def apply_policy_value(session: Session, key: str, value, *,
                       source: str, actor: str | None = None) -> dict:
    """Validate, write and record one threshold change.

    Does not commit - the caller decides whether a batch of edits lands as one
    unit. Raises PolicyEditError with a readable reason rather than returning a
    sentinel, because both callers have to relay that reason to a person.
    """
    row = session.get(PolicyConfig, key)
    if not row:
        known = ", ".join(sorted(k for (k,) in session.execute(
            select(PolicyConfig.key))))
        raise PolicyEditError(f"unknown policy key '{key}'. Known keys: {known}")

    try:
        new_value = Decimal(str(value))
    except (InvalidOperation, TypeError) as exc:
        raise PolicyEditError(f"'{value}' is not a number") from exc

    limits = POLICY_LIMITS.get(key)
    if limits:
        lo, hi, integer_only = limits
        if not (lo <= new_value <= hi):
            raise PolicyEditError(
                f"{key} must be between {lo} and {hi} ({row.unit or 'unitless'})")
        if integer_only and new_value != new_value.to_integral_value():
            raise PolicyEditError(f"{key} must be a whole number")

    old_value = Decimal(str(row.value))
    if old_value == new_value:
        return {"key": key, "old_value": str(old_value),
                "new_value": str(new_value), "unit": row.unit,
                "changed": False}

    row.value = new_value
    session.add(PolicyChange(
        key=key,
        old_value=str(old_value),
        new_value=str(new_value),
        source=source,
        actor=actor,
    ))
    log.info("policy_config %s: %s -> %s (by %s)", key, old_value, new_value, source)
    return {"key": key, "old_value": str(old_value), "new_value": str(new_value),
            "unit": row.unit, "changed": True}


def policy_change_log(session: Session, limit: int = 50) -> list[dict]:
    """Threshold edits, newest first, whoever made them."""
    rows = session.scalars(
        select(PolicyChange).order_by(PolicyChange.created_at.desc()).limit(limit)
    ).all()
    return [
        {
            "key": r.key,
            "old_value": r.old_value,
            "new_value": r.new_value,
            "source": r.source,
            "actor": r.actor,
            "changed_at": r.created_at.isoformat() if r.created_at else None,
        }
        for r in rows
    ]
