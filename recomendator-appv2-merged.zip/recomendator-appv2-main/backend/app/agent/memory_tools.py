"""Tools that see past one run.

Every tool in `tools.py` takes a run id and reads inside that one run, which
is why the agent could never answer "what changed when I raised the ceiling?"
- not because the earlier run was lost, but because nothing handed it over.
It was never lost: an EvaluationRun is immutable and stores both its inputs
(`policy_snapshot`, `quote_ids`) and its full output (`result`), and every run
for a batch shares a `comparison_id`. The history was already on disk.

So these tools are scoped to the batch rather than the run, and the diffing is
done here in Python rather than left to the model. That is not tidiness. The
agent's standing instruction forbids it from doing arithmetic, for the good
reason that a number it works out itself can disagree with the dashboard. A
delta is arithmetic. If the agent is to say a total moved by EUR 4,120, this
module has to be what subtracted.
"""
from __future__ import annotations

import logging
from decimal import Decimal, InvalidOperation

from sqlalchemy import select

from ..db import SessionLocal
from ..models import EvaluationRun

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _flatten(value: dict | None, prefix: str = "") -> dict:
    """Flatten policy_snapshot so nested keys diff as plainly as flat ones.

    Without this, a change to the USD rate shows up as one whole `fx` dict
    replacing another and the agent has to work out which currency moved.
    """
    out: dict = {}
    for key, item in (value or {}).items():
        path = f"{prefix}{key}"
        if isinstance(item, dict):
            out.update(_flatten(item, f"{path}."))
        else:
            out[path] = item
    return out


def _num(value):
    """Decimal if this reads as a number, else None. Snapshots store strings."""
    if value is None or isinstance(value, bool):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _delta(before, after):
    """The signed difference, when both sides are numeric. Never the model's job."""
    a, b = _num(before), _num(after)
    if a is None or b is None:
        return None
    return str(b - a)


def _load(run_id: str) -> EvaluationRun | None:
    with SessionLocal() as session:
        return session.get(EvaluationRun, run_id)


def _ranking(result: dict) -> list[dict]:
    return [
        {
            "supplier_id": s["supplier_id"],
            "supplier_name": s["supplier_name"],
            "total_landed_cost_eur": s.get("total_landed_cost_eur"),
            "final_rank": s.get("final_rank"),
            "award_status": s.get("award_status"),
            "eligible": s.get("eligible"),
            "failed_gate": s.get("failed_gate"),
        }
        for s in (result or {}).get("suppliers", [])
    ]


# ---------------------------------------------------------------------------
# reading the history
# ---------------------------------------------------------------------------

def list_runs(comparison_id: str) -> dict:
    """Every evaluation run for this batch of quotes, newest first.

    Use this to find an earlier run before comparing against it. Each entry
    carries the thresholds that run was evaluated under, so a threshold change
    between two runs is visible without opening either one.

    Args:
        comparison_id: identifier of the batch of quotes.
    """
    with SessionLocal() as session:
        runs = session.scalars(
            select(EvaluationRun)
            .where(EvaluationRun.comparison_id == comparison_id)
            .order_by(EvaluationRun.created_at.desc())
        ).all()

    return {
        "run_count": len(runs),
        "runs": [
            {
                "run_id": run.run_id,
                "created_at": run.created_at.isoformat() if run.created_at else None,
                "is_latest": index == 0,
                "engine_version": run.engine_version,
                "quote_count": len(run.quote_ids or []),
                "policy": _flatten(run.policy_snapshot),
                "kpis": (run.result or {}).get("kpis", {}),
                "ranking": _ranking(run.result or {}),
            }
            for index, run in enumerate(runs)
        ],
    }


def get_policy_snapshot(run_id: str) -> dict:
    """The thresholds and constants one run was actually evaluated under.

    A run never re-reads policy_config, so this is what that run used, not
    what is configured now. get_current_policy is what is configured now.

    Args:
        run_id: identifier of the evaluation run.
    """
    run = _load(run_id)
    if not run:
        return {"error": "no such run"}
    return {
        "run_id": run.run_id,
        "created_at": run.created_at.isoformat() if run.created_at else None,
        "policy": _flatten(run.policy_snapshot),
    }


def get_current_policy() -> dict:
    """The thresholds configured right now, and the log of edits to them.

    These are what the next evaluation will use. They are not necessarily what
    the run on screen used - compare with get_policy_snapshot before saying a
    figure was in force for a given run.
    """
    from ..models import PolicyConfig
    from ..policy_edit import policy_change_log

    with SessionLocal() as session:
        rows = session.scalars(select(PolicyConfig)).all()
        return {
            "policy": [
                {"key": r.key, "value": str(r.value), "unit": r.unit,
                 "description": r.description}
                for r in rows
            ],
            "recent_changes": policy_change_log(session, limit=20),
        }


def compare_runs(run_id_before: str, run_id_after: str) -> dict:
    """What changed between two runs of the same batch: inputs and outcomes.

    Returns the policy keys that differ, the KPI movements and the per-supplier
    movements in cost, rank, eligibility and award status. Every difference is
    calculated here, so quote the numbers as returned.

    Read `inputs_identical` before attributing anything. If the two runs were
    evaluated over different quotes, a threshold change is not the only thing
    that moved and saying it caused the result would be wrong.

    Args:
        run_id_before: the earlier run.
        run_id_after: the later run.
    """
    before, after = _load(run_id_before), _load(run_id_after)
    if not before or not after:
        return {"error": "one or both runs not found"}
    if before.comparison_id != after.comparison_id:
        return {"error": "those two runs belong to different batches of quotes; "
                         "they are not comparable"}

    quotes_before = set(before.quote_ids or [])
    quotes_after = set(after.quote_ids or [])
    inputs_identical = quotes_before == quotes_after

    policy_before = _flatten(before.policy_snapshot)
    policy_after = _flatten(after.policy_snapshot)
    policy_changes = [
        {"key": key,
         "before": policy_before.get(key),
         "after": policy_after.get(key),
         "change": _delta(policy_before.get(key), policy_after.get(key))}
        for key in sorted(set(policy_before) | set(policy_after))
        if policy_before.get(key) != policy_after.get(key)
    ]

    kpis_before = (before.result or {}).get("kpis", {})
    kpis_after = (after.result or {}).get("kpis", {})
    kpi_changes = [
        {"metric": key,
         "before": kpis_before.get(key),
         "after": kpis_after.get(key),
         "change": _delta(kpis_before.get(key), kpis_after.get(key))}
        for key in sorted(set(kpis_before) | set(kpis_after))
        if kpis_before.get(key) != kpis_after.get(key)
    ]

    ranked_before = {s["supplier_id"]: s for s in _ranking(before.result or {})}
    ranked_after = {s["supplier_id"]: s for s in _ranking(after.result or {})}
    supplier_changes = []
    for supplier_id in sorted(set(ranked_before) | set(ranked_after)):
        was = ranked_before.get(supplier_id, {})
        now = ranked_after.get(supplier_id, {})
        row = {
            "supplier_id": supplier_id,
            "supplier_name": now.get("supplier_name") or was.get("supplier_name"),
            "in_before_run": supplier_id in ranked_before,
            "in_after_run": supplier_id in ranked_after,
            "total_landed_cost_eur_before": was.get("total_landed_cost_eur"),
            "total_landed_cost_eur_after": now.get("total_landed_cost_eur"),
            "total_landed_cost_eur_change": _delta(
                was.get("total_landed_cost_eur"), now.get("total_landed_cost_eur")),
            "final_rank_before": was.get("final_rank"),
            "final_rank_after": now.get("final_rank"),
            "award_status_before": was.get("award_status"),
            "award_status_after": now.get("award_status"),
            "eligible_before": was.get("eligible"),
            "eligible_after": now.get("eligible"),
            "failed_gate_before": was.get("failed_gate"),
            "failed_gate_after": now.get("failed_gate"),
        }
        row["changed"] = any(
            row[f"{field}_before"] != row[f"{field}_after"]
            for field in ("total_landed_cost_eur", "final_rank",
                          "award_status", "eligible", "failed_gate")
        )
        supplier_changes.append(row)

    return {
        "run_id_before": run_id_before,
        "run_id_after": run_id_after,
        "created_at_before": before.created_at.isoformat() if before.created_at else None,
        "created_at_after": after.created_at.isoformat() if after.created_at else None,
        "inputs_identical": inputs_identical,
        "input_warning": None if inputs_identical else (
            "These runs were evaluated over different quotes "
            f"({len(quotes_before)} then {len(quotes_after)}), so a policy "
            "change is not the only thing that differs. Do not attribute the "
            "outcome to the policy change alone."
        ),
        "policy_changes": policy_changes,
        "kpi_changes": kpi_changes,
        "supplier_changes": supplier_changes,
        "ranking_changed": any(
            s["final_rank_before"] != s["final_rank_after"] for s in supplier_changes),
    }


# ---------------------------------------------------------------------------
# changing the policy and re-evaluating
# ---------------------------------------------------------------------------

def set_policy_value(key: str, value: float) -> dict:
    """Change one rule threshold or constant. Takes effect on the NEXT evaluation.

    This writes to the live configuration - it does not simulate anything, and
    it does not alter any run that has already happened. Nothing on the
    dashboard moves until run_evaluation is called afterwards.

    Call this only when the buyer has asked for the value to be changed. State
    the old value and the new one in your reply.

    Args:
        key: the policy key, for example ceiling_materiality_pct. Use
            get_current_policy for the list.
        value: the new value, in the unit that key is stored in.
    """
    from ..policy_edit import PolicyEditError, apply_policy_value

    with SessionLocal() as session:
        try:
            outcome = apply_policy_value(
                session, key, value, source="agent", actor="chat")
        except PolicyEditError as exc:
            return {"error": str(exc), "changed": False}
        session.commit()

    if not outcome["changed"]:
        outcome["note"] = "already set to that value; nothing was written"
    else:
        outcome["note"] = ("written to configuration. The dashboard still shows "
                           "the previous run until run_evaluation is called.")
    return outcome


def run_evaluation(comparison_id: str) -> dict:
    """Re-evaluate this batch under the current policy, creating a new run.

    The earlier run is untouched - it keeps its own thresholds and its own
    figures - so after this there are two runs to compare. Call compare_runs
    with the previous run id and the new one to report what moved, rather than
    describing the change from memory.

    Args:
        comparison_id: identifier of the batch of quotes to re-evaluate.
    """
    from ..evaluation import EvaluationError
    from ..evaluation import run_evaluation as _evaluate

    with SessionLocal() as session:
        previous = session.scalars(
            select(EvaluationRun)
            .where(EvaluationRun.comparison_id == comparison_id)
            .order_by(EvaluationRun.created_at.desc())
        ).first()
        previous_run_id = previous.run_id if previous else None

        try:
            run = _evaluate(session, comparison_id)
        except EvaluationError as exc:
            return {"error": str(exc), "run_id": None}

        log.info("agent re-evaluated %s -> run %s", comparison_id, run.run_id)
        return {
            "run_id": run.run_id,
            "previous_run_id": previous_run_id,
            "created_at": run.created_at.isoformat() if run.created_at else None,
            "kpis": (run.result or {}).get("kpis", {}),
            "ranking": _ranking(run.result or {}),
            "next_step": (
                "Call compare_runs(previous_run_id, run_id) and report the "
                "differences it returns." if previous_run_id else
                "This is the first run for this batch; there is nothing to "
                "compare it against."
            ),
        }


MEMORY_TOOLS = [
    list_runs,
    get_policy_snapshot,
    get_current_policy,
    compare_runs,
]

ACTION_TOOLS = [
    set_policy_value,
    run_evaluation,
]
