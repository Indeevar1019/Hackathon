"""Where a chat thread lives between requests.

The agent used to run under `InMemoryRunner`, which builds a session service
per call and throws it away with the answer. That is not a small leak of
context - it is total amnesia, and it is invisible in local testing because a
single process happens to answer every request. On Cloud Run the next question
can land on a different instance entirely, so an in-process session service is
one that works on a laptop and silently forgets in production.

This module holds one `DatabaseSessionService` for the process, pointed at the
same Cloud SQL database as everything else, so a thread survives both the end
of a request and the death of an instance.

Two things about it are not obvious:

* ADK's `DatabaseSessionService` calls `create_async_engine`, so it needs an
  async driver. `pg8000` - the sync driver the rest of the app uses - is
  rejected outright. `settings.async_sqlalchemy_url()` is the same database
  spelled for `asyncpg`; see the note there about the socket path differing.
* It is built lazily. Construction opens a connection and creates ADK's own
  tables, and doing that at import time would put a database round trip in the
  import path of every module that so much as mentions the agent, including
  the ones that never call it.
"""
from __future__ import annotations

import asyncio
import logging
import os

from ..config import settings

log = logging.getLogger(__name__)

APP_NAME = "sourcing-agent"

# Single-user proof of concept. When this grows real accounts, this becomes the
# signed-in user and the session key stops being guessable from a URL.
USER_ID = "buyer"

# Above this many stored events the thread is cut and started fresh.
#
# ADK replays the whole session to the model on every turn, so an unbounded
# thread means a prompt that grows without limit: rising cost, rising latency,
# and eventually a turn that cannot finish inside AGENT_TIMEOUT_SECONDS. This
# is a blunt cut, not a summary - the last N turns are lost, not compacted.
# That is tolerable here only because the durable memory is not the thread:
# every run and every policy change is in the database, and the tools can read
# all of it back at any time. The thread is convenience; the tables are truth.
MAX_SESSION_EVENTS = int(os.getenv("AGENT_MAX_SESSION_EVENTS", "80"))

# Pool size for the session store's own engine.
#
# This is a *second* engine against the same Cloud SQL instance - the app's
# queries still go through pg8000 on the sync one - so a Cloud Run instance now
# holds two pools, and the instance count multiplies both. Cloud SQL caps
# connections by tier (25 on db-f1-micro, 100 on db-g1-small), and running out
# does not fail politely: it fails as a timeout on whichever request happens to
# ask next. The session store needs one connection per in-flight agent turn and
# nothing more, so it is deliberately small rather than left at SQLAlchemy's
# default of 5 + 10 overflow.
SESSION_POOL_SIZE = int(os.getenv("AGENT_SESSION_POOL_SIZE", "2"))
SESSION_MAX_OVERFLOW = int(os.getenv("AGENT_SESSION_MAX_OVERFLOW", "3"))


def _engine_kwargs(url: str) -> dict:
    """Engine settings passed through to create_async_engine.

    SQLite takes none of them - it has no pool worth sizing, and passing
    pool_size to it raises.
    """
    if url.startswith("sqlite"):
        return {}
    return {
        "pool_size": SESSION_POOL_SIZE,
        "max_overflow": SESSION_MAX_OVERFLOW,
        # Cloud SQL closes idle connections, and a pooled dead one surfaces as
        # a failed question rather than a reconnect. Same reason db.py sets it.
        "pool_recycle": 1800,
    }


_service = None
_lock = asyncio.Lock()


async def session_service():
    """The process-wide session service, built on first use."""
    global _service
    if _service is not None:
        return _service
    async with _lock:
        if _service is None:  # re-checked: two requests can queue on the lock
            from google.adk.sessions import DatabaseSessionService

            url = settings.async_sqlalchemy_url()
            _service = DatabaseSessionService(db_url=url, **_engine_kwargs(url))
            log.info("agent session store ready (%s)", url.split("://", 1)[0])
    return _service


def chat_session_id(comparison_id: str) -> str:
    """One thread per batch of quotes, deliberately not one per run.

    A re-evaluation creates a new `EvaluationRun`, and keying the thread on
    run id would mean every threshold change wiped the conversation that
    caused it - the buyer asks "what did that change?" in a session that has
    never heard of the previous run. The batch is the thing that persists
    across runs, so the batch is what the thread hangs off.
    """
    return f"chat-{comparison_id}"


async def open_thread(service, session_id: str):
    """Fetch the thread for this batch, creating or recycling it as needed."""
    session = None
    try:
        session = await service.get_session(
            app_name=APP_NAME, user_id=USER_ID, session_id=session_id)
    except Exception:  # noqa: BLE001 - a missing session is not an error here
        session = None

    if session is not None and len(session.events) > MAX_SESSION_EVENTS:
        log.info("chat thread %s exceeded %d events; starting a new one",
                 session_id, MAX_SESSION_EVENTS)
        await service.delete_session(
            app_name=APP_NAME, user_id=USER_ID, session_id=session_id)
        session = None

    if session is None:
        session = await service.create_session(
            app_name=APP_NAME, user_id=USER_ID, session_id=session_id)
    return session


async def reset_thread(comparison_id: str) -> None:
    """Forget the conversation. Runs and policy history are untouched."""
    service = await session_service()
    try:
        await service.delete_session(
            app_name=APP_NAME, user_id=USER_ID,
            session_id=chat_session_id(comparison_id))
    except Exception:  # noqa: BLE001 - nothing to forget is a success
        pass
