# Agent memory + re-evaluation — what changed and how to apply it

## Read this first

**The zip you uploaded is the base commit. It does not contain the
`summary.md` changes.** I checked: `manual_override`, `_ensure_column`,
`PUT /reference/compliance` and the editable policy table in `app.js` are all
absent from the code I was given.

So my edits were made **on top of the base, not on top of your policy work**.
Dropping all ten files in wholesale would revert `summary.md` entirely. The
table below says which files are safe to copy and which have to be merged.

---

## What this adds

| Capability | How |
|---|---|
| Agent remembers earlier runs | `list_runs`, `get_policy_snapshot`, `compare_runs`, `get_current_policy` — batch-scoped, not run-scoped |
| Agent remembers the conversation | ADK `DatabaseSessionService` on the same Cloud SQL database, keyed on `comparison_id` |
| Agent can change a threshold and re-evaluate | `set_policy_value` → `run_evaluation` → `compare_runs`, in that order, enforced by the instruction |
| Dashboard follows a re-evaluation | `/ask` returns `run_changed` + `latest_run_id`; the page moves onto the new run and carries the answer across |
| Audit trail | New `policy_change` table records every edit, UI or agent |

The durable memory needed no new storage. `EvaluationRun` already froze
`policy_snapshot`, `quote_ids` and `result` per run — the history was on disk,
nothing handed it to the agent.

Deltas are computed in Python, never by the model. Your standing instruction
forbids the agent doing arithmetic, and a delta is arithmetic.

---

## Applying the changes

### Safe to copy over — you never touched these

| File | Note |
|---|---|
| `backend/app/agent/session_store.py` | **new** |
| `backend/app/agent/memory_tools.py` | **new** |
| `backend/app/policy_edit.py` | **new** |
| `backend/app/agent/agent.py` | instruction rewrite + persistent runner |
| `backend/app/agent/tools.py` | `ALL_TOOLS` → `READ_TOOLS` + memory + action sets |
| `backend/app/config.py` | adds `async_sqlalchemy_url()` |
| `backend/requirements.txt` | adds `asyncpg`, `aiosqlite` |

### Leave yours alone — I did not touch them

`backend/app/db.py` and `backend/app/seed.py`. Keep your `_ensure_column` and
your `manual_override` skip in the reconciliation loop. The new
`policy_change` table is picked up by `create_all` — it is a new table, not a
new column, so it needs no `ALTER` and no backfill.

### Merge by hand — three files

**1. `backend/app/models.py`**

Take *your* version (the one with `ComplianceRequirement.manual_override`) and
append the `PolicyChange` class from mine. It is the last block in the file and
touches nothing else.

**2. `backend/app/api/routes.py`** — the real merge

Start from *your* version, then:

- Replace your `PUT /reference/policy` body so it calls
  `policy_edit.apply_policy_value` instead of your local `POLICY_LIMITS` loop,
  and delete the local `POLICY_LIMITS` dict. **This matters**: two validators
  means a value the UI refuses is one the agent can set by asking politely.
  `policy_edit.py` already contains your bounds table verbatim.
- Add `reevaluate_comparison_id` to `PolicyBulkUpdate`, plus the
  `new_run_id` / `run_error` block at the end of the handler.
- Replace `ask_agent` with mine (passes `comparison_id`, returns
  `run_changed` / `latest_run_id`).
- Add `DELETE /comparisons/{id}/chat` and `GET /reference/policy-changes`.
- Keep your `PUT /reference/compliance` and your `manual_override` field in
  `GET /reference` exactly as they are. I did not touch compliance.

Your existing frontend policy-save handler keeps working unchanged — the
request shape is identical and `result.updated` / `result.errors` are both
still in the response. One cosmetic difference: mine only lists a key in
`updated` if the value actually *changed*, so re-saving an unchanged form now
toasts "0 threshold(s) updated" rather than counting it.

**3. `frontend/app.js`**

Start from *your* version (with the editable policy and compliance panels) and
port four small edits from mine, all inside the run dashboard — none of them
go near your `reference()` function:

1. `data-comparison-id` on the "Back to batch" link.
2. The `chat-intro` paragraph text.
3. The "Start a new conversation" row after `<div id="answer">`.
4. In `ask()`: the `response.run_changed` block, and the `carry-answer`
   restore + `chat-reset` handler just above `$("ask-btn").onclick`.

---

## Deploying

No new env vars are required. Optional ones:

```
AGENT_MAX_SESSION_EVENTS=80     # thread length before a hard cut
AGENT_SESSION_POOL_SIZE=2       # session store's own connection pool
AGENT_SESSION_MAX_OVERFLOW=3
```

Then rebuild — `asyncpg` and `aiosqlite` are new. Both ship manylinux wheels,
so the image still needs no libpq and no compiler.

On first request the agent's session store creates ADK's own tables
(`sessions`, `events`, `app_states`, `user_states`) in your Cloud SQL
database. Your DB user already has CREATE, so nothing to grant — but they will
appear in your schema unannounced, which is worth knowing before someone asks.

### If you have an `a2a.py`

Point it at `build_readonly_agent()`, not `build_agent()`. It was not in the
zip so I could not patch it. Without that change a remote A2A caller can move
`ceiling_materiality_pct` on your deployment as a side effect of asking a
question.

---

## Verified before delivery

Run against a real SQLite database, not just compiled:

1. `py_compile` on every touched Python file — clean. `node --check` on
   `app.js` — clean.
2. `async_sqlalchemy_url()` for all three Cloud SQL configurations
   (`INSTANCE_CONNECTION_NAME`, `DATABASE_URL` with `+pg8000`, bare
   `postgresql://`) — correct driver, correct socket spelling, password not
   masked.
3. `apply_policy_value` accepted a valid edit and rejected a negative
   percentage, a fractional integer key and an unknown key, each with a
   readable reason.
4. `policy_change` recorded old value, new value and source.
5. `compare_runs` across two fabricated runs — detected the threshold change,
   the nested `fx.USD` change, the KPI movement and the rank swap, with signed
   deltas computed in Python.
6. `session_store` — created a thread, reopened the same one, reset it,
   confirmed the service is a process-wide singleton.

Not verified: anything against your actual Cloud SQL instance, and no LLM turn
was executed (no Vertex credentials here). The line I would watch on first
deploy is the asyncpg socket path — `host=` takes the directory, pg8000's
`unix_sock=` takes the full path. A connection refused against a path that
looks correct is the symptom.

## Known limitations

- **The thread cut is blunt.** Past 80 events the conversation is deleted and
  restarted, not summarised. Survivable only because the runs table is the real
  memory — the tools can read it all back.
- **No confirmation step on writes.** You chose the direct write/re-evaluate
  tool over propose-and-confirm. The instruction says to change a threshold
  only when asked, but that is a prompt, not a guard rail. The audit trail is
  what makes it recoverable, not preventable.
- **Still no auth**, consistent with the rest of the POC — but the blast radius
  is larger now: anyone who can reach `/ask` can move a threshold.
- **`compare_runs` warns, it does not block.** If two runs used different
  quotes it sets `inputs_identical: false` and tells the agent not to attribute
  the change to policy. That relies on the model honouring the field.
