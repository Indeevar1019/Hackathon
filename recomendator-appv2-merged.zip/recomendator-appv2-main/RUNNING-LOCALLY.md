# Running backend and frontend individually in Cloud Shell

Two separate processes, backend on 8080 and frontend on 8081, talking to each
other — this is the closer match to how Cloud Run actually runs them (two
services), as opposed to `SERVE_FRONTEND=1`, which serves both from one
process and skips the cross-origin link entirely.

`app.js` calls a relative path — `const API = "/api"` — which only resolves
correctly if something on the frontend's own origin forwards `/api/*` to the
backend. In Cloud Run that something is nginx (`frontend/default.conf.template`).
Locally, without Docker, this repo now ships `frontend/dev_server.py` — a
small stdlib-only static file server that does the same proxying, so app.js
does not need to know or care that the backend is a separate process.

## 1. Backend: venv and env

```bash
cd ~/recomendator-appv2-main/backend
python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements.txt
```

Copy the example env and fill it in — this is the same file from before,
nothing new required for this step:

```bash
cp ../.env.example .env
```

Edit `.env`. Minimum for local testing without Vertex or Document AI:

```bash
GCP_PROJECT=
DATABASE_URL=sqlite+pysqlite:///./quotepoc.db
```

Or point `INSTANCE_CONNECTION_NAME` / `DATABASE_URL` at Cloud SQL through the
Auth Proxy, exactly as in `TESTING-CLOUD-SHELL.md` — that guide's steps 2–3
are unchanged by this one; this document only replaces "how you start
uvicorn and where the frontend comes from."

Load it and start the backend:

```bash
set -a; . ./.env; set +a
uvicorn app.main:app --port 8080 --reload
```

Leave this running. In its own log you should see `schema ready, N tables
present` and `Uvicorn running on http://127.0.0.1:8080`.

**Do not set `SERVE_FRONTEND=1` here** — that mounts the frontend inside this
same process, which is the other way to run this stack, not this one.

Confirm it's up, in a second tab:

```bash
curl -s localhost:8080/healthz
```

## 2. Frontend: its own process, linked to the backend

Second tab, no venv needed — `dev_server.py` is stdlib only:

```bash
cd ~/recomendator-appv2-main/frontend
BACKEND_URL="http://localhost:8080" python3 dev_server.py 8081
```

That's the whole link: one environment variable. `dev_server.py` serves
`index.html`, `app.js`, `styles.css` directly, and forwards anything under
`/api/` — GET, POST, PUT, DELETE, including the multipart quote uploads and
the streamed request bodies for `PUT /reference/policy` — to `BACKEND_URL`
untouched.

Its log tags each request so you can see the link working:

```
[static] "GET /index.html HTTP/1.1" 200 -
[proxy->backend] "GET /api/reference HTTP/1.1" 200 -
```

## 3. Open it

**Web Preview → Change port → 8081** — not 8080. The backend has no `/` route
of its own unless `SERVE_FRONTEND=1` is set, and it isn't here.

## 4. Confirm the link end to end

Third tab, while both are running:

```bash
# through the frontend's proxy
curl -s localhost:8081/api/reference/policy-changes

# same call, straight to the backend
curl -s localhost:8080/api/reference/policy-changes
```

Both should return the same JSON. If the first hangs or returns a 502 with
"Cannot reach backend", `BACKEND_URL` is wrong or uvicorn isn't up — that
error message names both possibilities directly.

A write through the proxy should show up on a direct read of the backend
too, confirming the proxy isn't just echoing something local:

```bash
curl -s -X PUT localhost:8081/api/reference/policy \
  -H 'Content-Type: application/json' \
  -d '{"updates":[{"key":"ceiling_materiality_pct","value":3}]}'

curl -s localhost:8080/api/reference/policy-changes
```

I ran exactly this sequence before handing this over — static file, a
proxied `GET`, a proxied `PUT` that the validator rejects, and a proxied
`PUT` that succeeds and is then visible from a direct call to the backend on
its own port. All four passed.

## 5. Iterating

Both processes run with reload/no build step:

- `--reload` on uvicorn picks up backend Python changes automatically.
- `app.js`, `index.html`, `styles.css` are served straight off disk by
  `dev_server.py` on every request — edit, save, refresh the browser tab. No
  restart needed for frontend-only changes.

If you add a new backend route, no frontend restart is needed either — the
proxy forwards by path, it has no route table of its own to update.

## 6. Shutting down

`Ctrl-C` in each tab. `dev_server.py` holds no state and touches no files
outside `frontend/`; the backend's state is wherever `DATABASE_URL` points —
`quotepoc.db` locally, or your Cloud SQL database if that's what you set.

## What this is not

`dev_server.py` is dev tooling for exactly this scenario — it is not part of
the deployed image, it's not referenced by `frontend/Dockerfile`, and it
should not be. In Cloud Run, nginx does this job; here, since Docker adds a
layer this guide didn't need, a 130-line stdlib script does the same one
thing nginx's `default.conf.template` does — proxy `/api/` — without needing
nginx or Docker present in Cloud Shell at all.
