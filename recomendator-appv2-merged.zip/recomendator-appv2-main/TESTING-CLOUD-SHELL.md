# Testing in Cloud Shell against Cloud SQL

This runs the merged code in Cloud Shell against your **real Cloud SQL
Postgres instance**, through the Cloud SQL Auth Proxy. Nothing is deployed —
uvicorn runs in Cloud Shell, the database is the live one.

## First: use a separate database, not your live one

Everything here writes. Policy edits land in `policy_config`, the audit trail
in `policy_change`, and ADK creates four tables of its own on first use
(`sessions`, `events`, `app_states`, `user_states`). A re-evaluation creates a
real `evaluation_run`.

Same instance, different database — that exercises Postgres and asyncpg
properly while leaving your data alone:

```bash
gcloud sql databases create quotepoc_test --instance=YOUR_INSTANCE
```

Use `quotepoc` instead only if you genuinely want to test against live data.

## 1. Upload and install

Open [shell.cloud.google.com](https://shell.cloud.google.com), **File → Upload
Files** in the Editor, then:

```bash
cd ~ && unzip -o recomendator-appv2-merged.zip
cd recomendator-appv2-main
python3 -m venv .venv && . .venv/bin/activate
pip install -q -r backend/requirements.txt
```

`asyncpg` and `aiosqlite` are the two new lines. Both should install from
manylinux wheels — if either compiles, the pin is wrong.

## 2. Start the Cloud SQL Auth Proxy — on a unix socket

Use the **socket**, not TCP. On Cloud Run the app connects over
`/cloudsql/INSTANCE`, and the socket path is spelled differently for the two
drivers: pg8000 wants the full path in `unix_sock=`, asyncpg wants the
directory in `host=`. TCP would work and would test none of that.

In a first Cloud Shell tab:

```bash
sudo mkdir -p /cloudsql && sudo chown $USER /cloudsql
cloud-sql-proxy --unix-socket /cloudsql PROJECT:REGION:INSTANCE
```

`cloud-sql-proxy` is preinstalled in Cloud Shell. Your own credentials are
already there, so no key file — you need `roles/cloudsql.client`, which you
almost certainly have. Leave this running.

Sanity check in a second tab:

```bash
ls /cloudsql/PROJECT:REGION:INSTANCE/
```

Expect `.s.PGSQL.5432`. If that file is missing, the app cannot connect and
nothing below will work.

## 3. Start the app

Second tab, `cd ~/recomendator-appv2-main`, `. .venv/bin/activate`:

```bash
cd backend
export INSTANCE_CONNECTION_NAME="PROJECT:REGION:INSTANCE"
export DB_USER=postgres
export DB_PASSWORD='your-password'
export DB_NAME=quotepoc_test
export SERVE_FRONTEND=1
export GCP_PROJECT=""            # telemetry off for now; Vertex comes in step 5

uvicorn app.main:app --port 8080 --reload
```

Do **not** set `DATABASE_URL` — leaving it unset is what makes the app take the
`INSTANCE_CONNECTION_NAME` branch, which is the branch Cloud Run uses.

Three things to look for in the startup log:

| Line | Means |
|---|---|
| `schema ready, N tables present` | `create_all` ran. `policy_change` is new and needs no ALTER. |
| `added column compliance_requirement.manual_override` | Only on a database created before this change. On a fresh `quotepoc_test` the column exists from the start and the line is absent. Either is correct. |
| *(no error mentioning `BOOLEAN DEFAULT 0`)* | Your `summary.md` version used `DEFAULT 0`, which SQLite accepts and **Postgres rejects**. Fixed in this zip to `DEFAULT FALSE`. This is the step where the old version would have failed. |

Then **Web Preview → Preview on port 8080**.

## 4. Test without Vertex

Third tab. No credentials needed for any of this.

**Thresholds edit and validate:**

```bash
curl -s -X PUT localhost:8080/api/reference/policy \
  -H 'Content-Type: application/json' \
  -d '{"updates":[{"key":"ceiling_materiality_pct","value":4},
                  {"key":"min_supplier_count","value":2.5}]}' | python3 -m json.tool
```

First lands, second is rejected as "must be a whole number" — one bad row does
not sink the batch.

**The audit trail:**

```bash
curl -s localhost:8080/api/reference/policy-changes | python3 -m json.tool
```

**A manual compliance edit survives a cold start** — the bug `manual_override`
exists for:

```bash
curl -s -X PUT localhost:8080/api/reference/compliance \
  -H 'Content-Type: application/json' \
  -d '{"updates":[{"code":"ISO_9001","tier":"MANDATORY"}]}'
```

Restart uvicorn (Ctrl-C, up-arrow, Enter), then:

```bash
curl -s localhost:8080/api/reference \
  | python3 -c "import json,sys; print([c for c in json.load(sys.stdin)['compliance_requirements'] if c['code']=='ISO_9001'])"
```

Expect `MANDATORY` with `manual_override: true`. Before this change `seed.py`
reverted it on every start.

**Check it in Postgres directly:**

```bash
gcloud sql connect YOUR_INSTANCE --user=postgres --database=quotepoc_test
```

```sql
\d policy_change
SELECT key, old_value, new_value, source FROM policy_change ORDER BY created_at DESC LIMIT 5;
SELECT code, tier, manual_override FROM compliance_requirement;
```

## 5. Test the agent — needs Vertex

```bash
gcloud auth application-default login
gcloud config set project YOUR_PROJECT
```

Restart uvicorn with the project set:

```bash
export GCP_PROJECT=YOUR_PROJECT
export VERTEX_LOCATION=global
export VERTEX_MODEL=gemini-2.5-flash
uvicorn app.main:app --port 8080 --reload
```

**This is the moment asyncpg is first exercised.** The session store is built
lazily, on the first `/ask` — not at startup. Watch for:

```
agent session store ready (postgresql)
```

If it says `sqlite`, the async URL fell through to the local fallback and the
thread will not survive a restart, let alone a Cloud Run instance change. If
you get a connection refused against a path that looks correct, that is the
`host=` vs `unix_sock=` difference, and it is the one line worth suspecting.

You need a batch with real quotes, which means Document AI — set
`DOCAI_PROCESSOR_ID`, `DOCAI_LOCATION` and `GCS_BUCKET` and upload through the
UI. There is no seeded sample comparison.

Then on a run dashboard, ask in order:

1. **"Why is <supplier> ranked first?"** — baseline, reads the stored run.
2. **"Change ceiling_materiality_pct to 2 and re-evaluate."** — should call
   `set_policy_value`, `run_evaluation`, `compare_runs`; state old and new
   value; report what moved. The page then swaps to the new run.
3. **"What changed compared to the previous run?"** — cross-run memory. Should
   answer without you re-supplying either run id.
4. **"What did I ask you first?"** — the thread rather than the tools. Fails on
   the old code; works now.

Confirm the thread is really in Cloud SQL:

```sql
SELECT id, app_name, user_id FROM sessions;
SELECT count(*) FROM events;
```

Expect `chat-<comparison_id>`. Restart uvicorn and ask question 4 again — it
should still answer, which is the whole point of moving off `InMemoryRunner`.

## 6. Connection count

You now have two pools against one instance. Check what you are actually using:

```sql
SELECT count(*), application_name FROM pg_stat_activity
WHERE datname = 'quotepoc_test' GROUP BY application_name;
```

The session store's pool is capped at 2 + 3 overflow
(`AGENT_SESSION_POOL_SIZE`). On Cloud Run this multiplies by instance count,
and Cloud SQL caps connections by tier — 25 on `db-f1-micro`, 100 on
`db-g1-small`. Exhausting it surfaces as a timeout on whichever request asks
next, not as a clear error, so it is worth knowing your headroom before this
sees load.

## 7. Clean up

```bash
gcloud sql databases delete quotepoc_test --instance=YOUR_INSTANCE
```

Or keep the database and drop just the conversation:

```bash
curl -s -X DELETE localhost:8080/api/comparisons/<comparison_id>/chat
```

That clears the thread only. Runs, policy snapshots and the audit trail stay —
the agent can still read all of them back with its tools.

---

## If you would rather not run the proxy on a socket

TCP works and is simpler, but does not test the socket path:

```bash
cloud-sql-proxy --port 5432 PROJECT:REGION:INSTANCE   # tab one
export DATABASE_URL="postgresql+pg8000://postgres:PASSWORD@127.0.0.1:5432/quotepoc_test"
```

`async_sqlalchemy_url()` rewrites the driver to `asyncpg` and leaves the host
alone, so the session store follows automatically. Just be aware you have then
verified Postgres and asyncpg, but not the `/cloudsql` socket spelling that
Cloud Run actually uses.

## The SQLite fallback

Still there, and still the default when neither `DATABASE_URL` nor
`INSTANCE_CONNECTION_NAME` is set. It is useful for checking that the app
boots and the endpoints respond without touching Cloud SQL at all — but it
tests neither driver you actually deploy with, so treat a green run on SQLite
as "not obviously broken", not as verification.
