# Testing in Cloud Shell Editor

Everything below runs in Cloud Shell against **SQLite**, so no Cloud SQL
instance is touched and nothing is deployed. The one part that needs real
credentials is the agent itself, which needs Vertex — that section is last and
marked.

## 1. Upload and open

Open [shell.cloud.google.com](https://shell.cloud.google.com), then in the
Editor: **File → Upload Files**, pick the zip, and in the terminal:

```bash
cd ~
unzip -o recomendator-appv2-merged.zip
cd recomendator-appv2-main
```

## 2. Install

Cloud Shell ships Python 3.12 and Node. A virtualenv keeps this off the
system interpreter, which Cloud Shell resets anyway.

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -q -r backend/requirements.txt
```

`asyncpg` and `aiosqlite` are the two new lines. Both install from manylinux
wheels — if either tries to compile, something is wrong with the pin.

## 3. Start it

```bash
cd backend
export DATABASE_URL="sqlite+pysqlite:///$HOME/quotepoc.db"
export SERVE_FRONTEND=1
export GCP_PROJECT=""          # telemetry off, no credentials needed
uvicorn app.main:app --port 8080 --reload
```

Startup should log `schema ready, N tables present`. Then **Web Preview →
Preview on port 8080** in the Cloud Shell toolbar.

Two things to confirm in that log, both new:

- `added column compliance_requirement.manual_override` — only on a database
  created before this change; on a fresh one the column is there from the
  start and the line is absent. Either is correct.
- No error about `policy_change`. It is a new table, so `create_all` makes it
  with no `ALTER` and no backfill.

## 4. Test without the agent

These need no Vertex credentials. Run them in a **second** Cloud Shell tab
(the first is running uvicorn), with `cd ~/recomendator-appv2-main`.

### Thresholds are editable and validated

```bash
curl -s -X PUT localhost:8080/api/reference/policy \
  -H 'Content-Type: application/json' \
  -d '{"updates":[{"key":"ceiling_materiality_pct","value":4},
                  {"key":"min_supplier_count","value":2.5}]}' | python3 -m json.tool
```

Expect the first to land and the second to be rejected as "must be a whole
number" — one bad row does not sink the batch.

### The change is on the record

```bash
curl -s localhost:8080/api/reference/policy-changes | python3 -m json.tool
```

Expect old value, new value and `"source": "ui"`.

### A manual compliance edit survives a restart

```bash
curl -s -X PUT localhost:8080/api/reference/compliance \
  -H 'Content-Type: application/json' \
  -d '{"updates":[{"code":"ISO_9001","tier":"MANDATORY"}]}' | python3 -m json.tool
```

Now restart uvicorn (Ctrl-C, up-arrow, Enter) and check it held:

```bash
curl -s localhost:8080/api/reference \
  | python3 -c "import json,sys; print([c for c in json.load(sys.stdin)['compliance_requirements'] if c['code']=='ISO_9001'])"
```

Expect `MANDATORY` with `manual_override: true`. Before this change, `seed.py`
reverted it on every cold start — that reversion is the bug the flag exists
for.

### In the browser

Open **Policy in force**. The thresholds table now has an input per row and a
Save button; the compliance table has an editable label, a tier dropdown and
an add row. A hand-edited code shows a `manual` pill.

## 5. Test the agent — needs Vertex

The chat, the cross-run memory and the re-evaluate tool all need real Gemini
calls. Cloud Shell is already authenticated as you, so:

```bash
gcloud auth application-default login
gcloud config set project YOUR_PROJECT
```

Restart uvicorn with the project set, in place of the empty value above:

```bash
export GCP_PROJECT=YOUR_PROJECT
export VERTEX_LOCATION=global
export VERTEX_MODEL=gemini-2.5-flash
uvicorn app.main:app --port 8080 --reload
```

You also need a batch with quotes in it, which means Document AI — so either
point `DOCAI_PROCESSOR_ID` / `GCS_BUCKET` at your real ones and upload
quotes through the UI, or test against a database you already have data in.
There is no seeded sample comparison; that is deliberate in this repo.

Then open a run dashboard and ask, in order:

1. **"Why is <supplier> ranked first?"** — baseline. Should read the stored
   run, exactly as before.
2. **"Change ceiling_materiality_pct to 2 and re-evaluate."** — should call
   `set_policy_value`, then `run_evaluation`, then `compare_runs`, state the
   old and new value, and report what moved. The page then swaps to the new
   run and the answer is carried across.
3. **"What changed compared to the previous run?"** — the real test of memory.
   It should answer from `compare_runs` without you re-supplying either run id.
4. **"What did I ask you first?"** — tests the thread rather than the tools.
   Fails on the old code; should work now.

If 3 or 4 come back blank, the session store is the thing to look at, not the
tools — check the startup log for `agent session store ready`.

## 6. Watch it work

```bash
sqlite3 ~/quotepoc.db "SELECT key, old_value, new_value, source FROM policy_change ORDER BY created_at DESC LIMIT 5;"
sqlite3 ~/quotepoc.db "SELECT run_id, created_at FROM evaluation_run ORDER BY created_at DESC LIMIT 5;"
sqlite3 ~/quotepoc.db "SELECT id, app_name, user_id FROM sessions;"
```

The last one is ADK's own table. `chat-<comparison_id>` is the thread. Those
four tables (`sessions`, `events`, `app_states`, `user_states`) are created by
ADK on first use and will appear in Cloud SQL too — worth knowing before
someone asks what they are.

## 7. Reset

```bash
rm ~/quotepoc.db     # everything: runs, policy edits, chat threads
```

Or just the conversation, leaving the runs and the audit trail:

```bash
curl -s -X DELETE localhost:8080/api/comparisons/<comparison_id>/chat
```

---

## Before deploying to Cloud Run

Nothing new is required. The optional variables are documented in
`.env.example` under the Vertex section. Rebuild the backend image —
`requirements.txt` changed.

On the first request after deploy, watch for `agent session store ready
(postgresql)`. If it says `sqlite`, the async URL fell through to the local
fallback and the thread will die with the container.

One line to watch: asyncpg takes the socket **directory** in `host=`, where
pg8000 takes the full path in `unix_sock=`. That is handled in
`config.async_sqlalchemy_url()`, but a connection refused against a path that
looks correct is the symptom if it is ever wrong.
